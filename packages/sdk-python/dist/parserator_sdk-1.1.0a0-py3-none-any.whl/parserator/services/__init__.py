"""
Parserator Services Package.

This package contains the core client and service implementations for the Parserator API.
"""

from .client import ParseratorClient

__all__ = ['ParseratorClient']